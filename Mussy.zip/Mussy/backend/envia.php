<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>recebedados</title>
</head>
<body>
    <?php 
    $conexao = mysqli_connect("localhost","root","","resevas_pets");
    //Checar conexão 

    
   
    
    // Verifica conexão
    if ($conexao->connect_error) {
        die("Erro de conexão: " . $conexao->connect_error);
    }
    
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // Dados do cliente
        $nome = $_POST['nome'];
        $email = $_POST['email'];
        $telefone = $_POST['telefone'];
    
        // Datas
        $data_entrada = $_POST['data_entrada'];
        $data_saida = $_POST['data_saida'];
    
        // Inserir cliente no banco
        $sql_cliente = "INSERT INTO clientes (nome, email, telefone) VALUES ('$nome', '$email', '$telefone')";
        if ($conexao->query($sql_cliente) === TRUE) {
            $cliente_id = $conexao->insert_id; // ID do cliente inserido
    
            // Capturar número de hóspedes
            $quantidade = $_POST['quantidade'];
    
            // Inserir informações dos animais
            for ($i = 1; $i <= $quantidade; $i++) {
                // Capturar nome do animal
                $nome_animal = $_POST["animal-name-$i"];
    
                // Capturar tamanhos selecionados
                $tamanhos = isset($_POST["animal-size-$i"]) ? $_POST["animal-size-$i"] : [];
                $tamanhos_str = is_array($tamanhos) ? implode(", ", $tamanhos) : $tamanhos;
    
                // Inserir no banco
                $sql_reservas = "INSERT INTO reservas (cliente_id, nome_animal, tamanho, data_entrada, data_saida) 
                                VALUES ('$cliente_id', '$nome_animal', '$tamanhos_str', '$data_entrada', '$data_saida')";
                $conexao->query($sql_reservas);
            }
    
            echo "Reserva realizada com sucesso!";
            echo"<a href ='http://localhost/mussy/reservas/index.html'>Voltar</a>";
        } else {
            echo "Erro ao salvar os dados do cliente: " . $conexao->error;
        }
    }
    ?>
    




















