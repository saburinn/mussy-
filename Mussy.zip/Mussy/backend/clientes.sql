-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 04, 2024 at 01:44 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `resevas_pets`
--

-- --------------------------------------------------------

--
-- Table structure for table `clientes`
--

CREATE TABLE `clientes` (
  `id` int(11) NOT NULL,
  `Nome` varchar(30) NOT NULL,
  `Email` varchar(80) NOT NULL,
  `Telefone` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `clientes`
--

INSERT INTO `clientes` (`id`, `Nome`, `Email`, `Telefone`) VALUES
(7, 'Nathalia', 'Nathaliasantos.silva111@gmail.com', '11964461156'),
(8, 'Carol', 'Carol@gmail.com.br', '11978546645'),
(9, '', '', ''),
(10, 'Pedro ', 'Pedro@gmail.com.br', '1199999999'),
(11, 'Sabrina ', 'Sabrina@gmail.com', '11 988441122'),
(12, 'Erivan', 'Erivan@gmail.com', '1199887744'),
(13, 'Julia ', 'Julia@gmail.com', '11911258744'),
(14, 'Laura', 'Laura@gmail.com.br', '11944226510'),
(15, 'Tiago ', 'tiago@gmail.com.br', '11932234488'),
(16, 'Gabriele ', 'Gabriele@gmail.com', '1195286644'),
(17, 'Nathalia', 'Nathaliasantos.silva111@gmail.com', '11 987415632'),
(18, 'Pedro ', 'PedroHerique@gmail.com.br', '1199884466'),
(19, 'Pedro ', 'PedroHerique@gmail.com.br', '1199884466'),
(20, 'Nathalia', 'Nathaliasantos.silva111@gmail', '1143081625'),
(21, 'Nathalia', 'Nathaliasantos.silva111@gmail', '1143081625'),
(22, 'Maria', 'MariaClara@gmail.com', '11998442233'),
(23, 'pedro', 'PedroHerique@gmail.com.br', '1198755552'),
(24, 'Celia ', 'Celia@gmail.com.br', '11 988777445'),
(25, 'Carol', 'Carol111@gmail.com.br', '11656491366');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
